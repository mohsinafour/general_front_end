import React, { Component } from "react";
import logo from "./logo.svg";
import "./App.css";
import Home from "./components/Components/Home";
import NewHome from "./components/Components/NewHome";

class App extends Component {
  render() {
    return (
      <div className="App">
        <NewHome />
      </div>
    );
  }
}

export default App;
