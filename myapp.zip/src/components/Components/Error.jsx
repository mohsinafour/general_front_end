import React, { Component } from "react";

class Error extends Component {
  state = {};
  render() {
    return <div>An Internal Server Error is occured, please try again</div>;
  }
}

export default Error;
