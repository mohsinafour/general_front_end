import React, { Component } from "react";
import { configure } from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import { shallow } from "enzyme";
import Home from "../Components/Home";

configure({ adapter: new Adapter() });

describe("Home Component Test Suite", () => {
  it("Home componenet should render", () => {
    const wrapper = shallow(<Home />);
    expect(
      wrapper.contains(
        <a
          color="white"
          href="http://localhost:8888/general/request_data?name=LINKEDIN"
        >
          <h2>Click here to fetch your data from LinkedIn</h2>
        </a>
      )
    ).toBe(true);
  });
});
